m = 2000
goal = 6000

print("Please enter cipher-text from Alice")
c = int(input())

print("The modified message is: " + str(int(goal*c/m)))